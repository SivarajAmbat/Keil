int uart0_getkey(void);
int uart1_getkey(void);
void uart1_init (void);
void uart0_init (void);
void uart1_putc	(char);
void uart0_putc	(char);
void uart1_puts	(char *);
void uart0_puts	(char *);
